package com.gadget;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GadgetSphereApplicationTests {

	@Test
	void contextLoads() {
	}

}
